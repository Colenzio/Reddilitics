// config/database.js
module.exports = {
	// connects to the local mongo db
	'url' : 'mongodb://localhost/reddilitics' // looks like mongodb://<user>:<pass>@mongo.onmodulus.net:27017/Mikha4ot

};